<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2017 Amasty (https://www.amasty.com)
 * @package Amasty_Customerattr
 */


class Amasty_Customerattr_Block_Adminhtml_Order_Create_Form_Account_Pure extends Amasty_Orderattr_Block_Adminhtml_Order_Create_Form_Account{}
