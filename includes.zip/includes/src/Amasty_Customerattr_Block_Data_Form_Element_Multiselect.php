<?php

/**
 * @author Amasty Team
 * @copyright Copyright (c) 2017 Amasty (https://www.amasty.com)
 * @package Amasty_Customerattr
 */
class Amasty_Customerattr_Block_Data_Form_Element_Multiselect
    extends Varien_Data_Form_Element_Multiselect
{
    public function __construct($attributes = array())
    {
        parent::__construct($attributes);
    }


}
