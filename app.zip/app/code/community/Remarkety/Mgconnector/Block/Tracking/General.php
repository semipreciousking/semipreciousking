<?php
class Remarkety_Mgconnector_Block_Tracking_General extends Remarkety_Mgconnector_Block_Tracking_Base
{

}
