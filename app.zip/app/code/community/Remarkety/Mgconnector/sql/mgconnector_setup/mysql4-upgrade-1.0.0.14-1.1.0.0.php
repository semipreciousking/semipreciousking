<?php

/**
 * Upgrade script from version 1.0.0.14 to 1.1.0.0
 *
 * @category   Remarkety
 * @package    Remarkety_Mgconnector
 * @author     Piotr Pierzak <piotrek.pierzak@gmail.com>
 */
$installer = $this;
$installer->startSetup();

$installer->endSetup();
