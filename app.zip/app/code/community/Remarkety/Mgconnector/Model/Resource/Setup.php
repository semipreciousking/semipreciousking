<?php

/**
 * Mgconnector resource setup model
 *
 * @category   Remarkety
 * @package    Remarkety_Mgconnector
 * @author     Piotr Pierzak <piotrek.pierzak@gmail.com>
 */
class Remarkety_Mgconnector_Model_Resource_Setup extends Mage_Core_Model_Resource_Setup
{

}
